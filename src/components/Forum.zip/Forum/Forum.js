import './Forum.css';
import { useState } from "react";
import Card from "../Card/Card";

const Forum =()=>{
    const [items] = useState([
        { title: "SLR", price: 211.99 },
        { title: "DSLR", price: 344.99 },
        { title: "Tripod", price: 12.99 },
      ]);
    let abc="https://www.freeiconspng.com/uploads/vintage-camera-png-images-for--camera-png--23.png"
      return (
        <div className="content">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="tile-container">
                    <div class="tile1">
                     <button style={{width:"50%", height:"140px",borderRadius:"50px",backgroundImage:'url('+ abc +')',backgroundRepeat:"no-repeat",backgroundSize:"cover", borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",mixBlendMode:"color-burn",paddingTop:"2em"}}></button>
                    <button style={{width:"100%", height:"141px",fontSize:"20px",color:"#3691B8",borderRadius:"50px", marginTop:"0px", marginLeft:"0px",  borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"0em", mixBlendMode:"color"}}>Upcoming Deals of the month! Upcoming Deals of the month! Upcoming</button>
                    </div>
                    <div class="tile">
                     <button style={{width:"50%", height:"140px",borderRadius:"50px",backgroundImage:'url('+ abc +')',backgroundRepeat:"no-repeat",backgroundSize:"cover", borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",mixBlendMode:"color-burn",paddingTop:"2em"}}></button>
                    <button style={{width:"100%", height:"141px",fontSize:"20px",color:"#3691B8",borderRadius:"50px", marginTop:"0px", marginLeft:"0px",  borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"0em", mixBlendMode:"color"}}>Top 10 most used softwares right now!! The article you dont want to miss!!</button>
                    </div>
                    <div class="tile">
                     <button style={{width:"50%", height:"140px",borderRadius:"50px",backgroundImage:'url('+ abc +')',backgroundRepeat:"no-repeat",backgroundSize:"cover", borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",mixBlendMode:"color-burn",paddingTop:"2em"}}></button>
                    <button style={{width:"100%", height:"141px",fontSize:"20px",color:"#3691B8",borderRadius:"50px", marginTop:"0px", marginLeft:"0px",  borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"0em", mixBlendMode:"color"}}>Upcoming photographers and videographers!! Artists who will become popular soon!!!</button>
                    </div>
                    <div class="tile1">
                     <button style={{width:"50%", height:"140px",borderRadius:"50px",backgroundImage:'url('+ abc +')',backgroundRepeat:"no-repeat",backgroundSize:"cover", borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",mixBlendMode:"color-burn",paddingTop:"2em"}}></button>
                    <button style={{width:"100%", height:"141px",fontSize:"20px",color:"#3691B8",borderRadius:"50px", marginTop:"0px", marginLeft:"0px",  borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"0em", mixBlendMode:"color"}}>Popular deals of the week! Popular Deals </button>
                    </div>
                    <div class="tile">
                     <button style={{width:"50%", height:"140px",borderRadius:"50px",backgroundImage:'url('+ abc +')',backgroundRepeat:"no-repeat",backgroundSize:"cover", borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",mixBlendMode:"color-burn",paddingTop:"2em"}}></button>
                    <button style={{width:"100%", height:"141px",fontSize:"20px",color:"#3691B8",borderRadius:"50px", marginTop:"0px", marginLeft:"0px",  borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"0em", mixBlendMode:"color"}}>Getting started with video editing and Photography</button>
                    </div>
                    <div class="tile">
                     <button style={{width:"50%", height:"140px",borderRadius:"50px",backgroundImage:'url('+ abc +')',backgroundRepeat:"no-repeat",backgroundSize:"cover", borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",mixBlendMode:"color-burn",paddingTop:"2em"}}></button>
                    <button style={{width:"100%", height:"141px",fontSize:"20px",color:"#3691B8",borderRadius:"50px", marginTop:"0px", marginLeft:"0px",  borderBlockColor:"transparent",borderRightColor:"transparent",borderLeftColor:"transparent",backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"0em", mixBlendMode:"color"}}>Top Secrets that professionals won’t tell you!!</button>
                    </div>
                       
                </div>
            </div>
        </div>
        </div>
      );
    
}

export default Forum;
