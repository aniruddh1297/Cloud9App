import './Home.css';

const Home = () => {
  return (
    <div className="content">
   
      <div className='tagline'>Capture Moments Make Memories</div>
    
      <a href="#" class="button">EXPLORE NOW</a>
      <div className='img'>&nbsp;</div>
    </div>
  );
};

export default Home;
