import "./Software.css";
import { useState } from "react";
import { Row, Col } from 'react-simple-flex-grid';

import { Link } from "react-router-dom";
import { fontSize, fontStyle } from "@mui/system";

const Software = () => {
  let [products] = useState({
    begineer: [ 1, 2, 3,4],
    intermediate: [1, 2, 3, 4],
    advance: [1, 2, 3, 4],
  });

  return (
    <div className="content">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="tile-container">
                <div>
                <div className="">
                  <button span={4}>col-4</button>
                  <button span={4}>col-4</button>
                  <button span={4}>col-4</button>
                </div>

                </div>
                <div>
                  <div className="tile1">
                    <button style={{width:"100%", height:"591px",fontSize:"20px",color:"#3691B8", borderRadius: "50px", marginTop:"0px", marginLeft:"0px",  backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"8em", mixBlendMode:"color-burn"}}>To help you out, we've
                    rounded up the very best video editing software available today in the article below. And we explain, in a way that's as free from technical jargon as possible, what each has to offer and what the main differences are between them.
                          </button>
                  </div>
                  <div className="tile">
                    <button style={{width:"100%", height:"591px", fontSize:"20px",color:"#3691B8",borderRadius: "50px", marginTop:"0px", marginLeft:"0px",  backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"8em", mixBlendMode:"color-burn"}}>To help you out, we've
                    rounded up the very  best video editing software available today in the article below. And we explain, in a way that's as free from technical jargon as possible, what each has to offer and what the main differences are between them.
</button>
                  </div>
                  <div className="tile">
                    <button style={{width:"100%", height:"591px",fontSize:"20px",color:"#3691B8", borderRadius: "50px", marginTop:"0px", marginLeft:"0px",  backgroundRepeat:"no-repeat", backgroundSize:"cover", paddingTop:"8em", mixBlendMode:"color-burn"}}>To help you out, we've
 rounded up the very 
best video editing
 software available today in the article below. And we explain, in a way that's as free from technical jargon as possible, what each has to offer and what the main differences are between them.</button>
                  </div>
                </div>
                </div>
            </div>
          </div>
    </div>
  );
};
export default Software;
